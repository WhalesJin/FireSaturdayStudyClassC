//
//  SecondEmojiCollectionViewCell.swift
//  230729_Study
//
//  Created by Minseong Kang on 2023/07/29.
//

import UIKit

class SecondEmojiCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var emojiLabel: UILabel!
    
    override func prepareForReuse() {
        super.prepareForReuse()
        updateCell()
    }
    
    func updateCell() {
        self.emojiLabel.translatesAutoresizingMaskIntoConstraints = false
        
        self.contentView.addSubview(emojiLabel)
        
        NSLayoutConstraint.activate([
            emojiLabel.topAnchor.constraint(equalTo: self.contentView.topAnchor),
            emojiLabel.leadingAnchor.constraint(equalTo: self.contentView.leadingAnchor),
            emojiLabel.trailingAnchor.constraint(equalTo: self.contentView.trailingAnchor),
            emojiLabel.bottomAnchor.constraint(equalTo: self.contentView.bottomAnchor)
        ])
    }
}
