//
//  FirstViewController.swift
//  230729_Study
//
//  Created by Minseong Kang on 2023/07/29.
//

import UIKit

class FirstViewController: UIViewController {
    let emojies = ["🔥", "🥰", "🥲", "👍", "👨‍🔬", "🤪", "🐸", "⚾️"]
    
    @IBOutlet weak var collectionView: UICollectionView!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
    }


}

extension FirstViewController: UICollectionViewDelegate, UICollectionViewDataSource {
    // MARK: - cell의 갯수
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return emojies.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as? EmojiCollectionViewCell else {
            return UICollectionViewCell()
        }
        
        cell.backgroundColor = .black
        
        
        cell.emojiLabel.text = emojies[indexPath.item]
        
        
        return cell
    }
}

extension FirstViewController {
    // MARK: - 위 아래 간격
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 10
    }
    
    // MARK: - 옆 간격
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumInteritemSpacingForSectionAt section: Int) -> CGFloat {
        return 20
    }
    
    // MARK: - 셀 사이즈(옆 라인을 고려하여 설정)
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        // 4등분하여 배치
        let width = (collectionView.frame.width / 4) - 20
        let height = (collectionView.frame.width / 4)
        let size = CGSize(width: width, height: height)
        return size
    }
}
