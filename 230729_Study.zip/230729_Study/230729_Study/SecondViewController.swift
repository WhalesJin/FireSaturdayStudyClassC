//
//  SecondViewController.swift
//  230729_Study
//
//  Created by Minseong Kang on 2023/07/29.
//

import UIKit

class SecondViewController: UIViewController {
    let emojies = ["🔥", "🥰", "🥲", "👍", "👨‍🔬", "🤪", "🐸", "⚾️"]
    
    @IBOutlet weak var collectionView: UICollectionView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.collectionView.delegate = self
        self.collectionView.dataSource = self
        
        collectionView.isPagingEnabled = true
    }
}

extension SecondViewController: UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    // MARK: - 컬랙션뷰 개수 설정
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return emojies.count
    }
    
    // MARK: - 컬랙션뷰 셀 설정
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        guard let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "cell", for: indexPath) as? SecondEmojiCollectionViewCell else {
            return UICollectionViewCell()
        }
        
        cell.backgroundColor = .yellow
        cell.emojiLabel.text = emojies[indexPath.item]
        
        return cell
    }
    
    // MARK: - 컬랙션뷰 사이즈 설정
    // UICollectionViewDelegateFlowLayout 상속
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.width
        let height = collectionView.frame.height

        return CGSize(width: width, height: height)
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, minimumLineSpacingForSectionAt section: Int) -> CGFloat {
        return 0
    }
}
