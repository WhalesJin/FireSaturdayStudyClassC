//
//  EmojiCollectionViewCell.swift
//  230729_Study
//
//  Created by Minseong Kang on 2023/07/29.
//

import UIKit

class EmojiCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var emojiLabel: UILabel!
    
    
}
