//
//  ViewController.swift
//  230805
//
//  Created by Minseong Kang on 2023/08/05.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var firstImageView: UIImageView!
    @IBOutlet weak var secondImageView: UIImageView!
    
    @IBOutlet weak var fetchFirstImageButton: UIButton!
    @IBOutlet weak var fetchSecondImageButton: UIButton!
    
    @IBOutlet weak var refreshImageButton: UIButton!
    @IBOutlet weak var refreshCacheButton: UIButton!
    
    var session: URLSession = URLSession.shared

    override func viewDidLoad() {
        super.viewDidLoad()
        // MARK: - 첫 번째 이미지 받아오기 버튼 탭 액션
        fetchFirstImageButton.addTarget(
            self,
            action: #selector(didTapFetchFirstImageButton),
            for: .touchUpInside
        )
        
        // MARK: - 두 번째 이미지 받아오기 버튼 탭 액션
        fetchSecondImageButton.addTarget(
            self,
            action: #selector(didTapFetchSecondImageButton),
            for: .touchUpInside
        )
        
        // MARK: - 이미지 초기화 버튼 탭 액션
        refreshImageButton.addTarget(
            self,
            action: #selector(didTapRefreshImageButton),
            for: .touchUpInside
        )
        
        // MARK: - 캐시 비우기 버튼 탭 액션
        refreshCacheButton.addTarget(
            self,
            action: #selector(didTapRefreshCacheButton),
            for: .touchUpInside
        )
    }
}

extension ViewController {
    @objc func didTapFetchFirstImageButton() {
        let firstImageURL = "https://wallpaperaccess.com/download/europe-4k-1369012"
        self.firstImageView.setupURLCache(imageURL: firstImageURL) { img in
            DispatchQueue.main.async {
                self.firstImageView.image = img
            }
        }
    }
    
    @objc func didTapFetchSecondImageButton() {
        let secondImageURL = "https://wallpaperaccess.com/download/europe-4k-1318341"
        self.secondImageView.setupURLCache(imageURL: secondImageURL) { img in
            DispatchQueue.main.async {
                self.secondImageView.image = img
            }
        }
    }
}

extension ViewController {
    @objc func didTapRefreshImageButton() {
        self.firstImageView.image = nil
        self.secondImageView.image = nil
        print("이미지를 초기화합니다.")
    }
    
    @objc func didTapRefreshCacheButton() {
        ImageCacheManager.shared.removeAllObjects()
        print("모든 캐시를 초기화 합니다.")
    }
}

extension ViewController {
    
}




extension ViewController {
    private func generateURL(urlRawData: String) throws -> URL {
        guard let url = URL(string: urlRawData) else {
            throw GenerateURLError.convert
        }
        return url
    }
    
    private func fetchImage(url: URL, completion: @escaping (UIImage) -> ()) {
        session.dataTask(with: url) { data, response, error in
            guard error == nil else {
                print(error?.localizedDescription ?? "error 오류!")
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse,
                (200...299).contains(httpResponse.statusCode) else {
                print("httpResponse 오류!")
                return
            }
            
            guard let data = data else {
                print("데이터 오류!")
                return
            }
            
            guard let image = UIImage(data: data) else {
                print("이미지 변환 실패!")
                return
            }
            completion(image)
        }.resume()
    }
}

enum GenerateURLError: LocalizedError {
    case convert
    
    var errorDescription: String? {
        switch self {
        case .convert:
            return "URL 변환에 실패하였습니다."
        }
    }
}
