//
//  ImageRepository.swift
//  230805
//
//  Created by Minseong Kang on 2023/08/05.
//

import UIKit

//class ImageRepository {
//    let cache = URLCache.shared
//    
//    func loadImageFromCache(imgURL: URL, completion: @escaping (UIImage) -> ()) {
//        let request = URLRequest(url: imgURL)
//        
//        DispatchQueue.global().async {
//            let dataTask = URLSession.shared.dataTask(with: imgURL) { data, response, error in
//                
//                guard let response = response else {
//                    return
//                }
//                
//                guard let data = data else {
//                    return
//                }
//                
//                let cacheData = CachedURLResponse(response: response, data: data)
//                self.cache.storeCachedResponse(cacheData, for: request)
//                print("새로운 이")
//                guard let img = UIImage(data: data) else {
//                    return
//                }
//                completion(img)
//            }
//            dataTask.resume()
//        }
//        
//        DispatchQueue.global(qos: .userInitiated).async {
//            guard let data = self.cache.cachedResponse(for: request)?.data else {
//                return
//            }
//            
//            guard let img = UIImage(data: data) else {
//                return
//            }
//            completion(img)
//        }
//    }
//    
//    func setImageURLWithCache(_ imgURL: URL, completion: @escaping (UIImage) -> ()) {
//        let request = URLRequest(url: imgURL)
//        /// qos == 우선순위!!
//        /// 네트워크 -> 백그라운드에서 돌아가게 만드는 방법은 따로 있음
//        DispatchQueue.global(qos: .background).async {
//            
//            /// cache할 객체의 key값을 string으로 생성
//            let cachedKey = NSString(string: url)
//            
//            /// cache된 이미지가 존재하면 그 이미지를 사용(API 호출안하는 형태)
//            if let cachedImage = ImageCacheManager.shared.object(forKey: cachedKey) {
//                DispatchQueue.main.async {
//                    self.image = cachedImage
//                    print("캐시된 데이터가 있습니다.")
//                }
//                return
//            }
//            
//            guard let url = URL(string: imgURL) else { return }
//            URLSession.shared.dataTask(with: url) { (data, response, error) in
//                guard error == nil else {
//                    print(error?.localizedDescription ?? "오류 발생!!")
//                    return
//                }
//                
//                DispatchQueue.main.async { [weak self] in
//                    /// [weak self] 사용 이유
//                    /// 클로저에서 self를 캡쳐할 때 `[weak self]`를 사용하는 경우는 순환 참조 방지
//                    /// 약한 참조로 클로저 내부에서 해당 클래스의 인스턴스를 사용할 때
//                    /// -> 클로져에서 약한 참조를 이용해 특정 인스턴스를 캡쳐하지 않으면
//                    /// -> self 가 해제될 때까지 기다리고 self는 클로저가 해제될 때까지 기다리는
//                    /// -> strong reference cycle 상황을 만들어 내게 됨
//                    /// -> 이러한 상황을 해결하기 위해 사용
//                    /// -> 따라서 클로저에서 특정 인스턴스를 캡처할 때 약한참조(ex.`[weak self]`)를
//                    /// 하는 이유는 Retain Cycle(순환 참조)로 인한 메모리 누수(memery leak)을 방지하기 위해 사용.
//                    guard let data = data else { return }
//                    
//                    guard let image = UIImage(data: data) else {
//                        return
//                    }
//                    print("새로운 이미지를 받아왔습니다.")
//                    ImageCacheManager.shared.setObject(image, forKey: cachedKey)
//                    self?.image = image
//                }
//            }.resume()
//        }
//    }
//}
