//
//  URLCacheManager.swift
//  230805
//
//  Created by Minseong Kang on 2023/08/05.
//

import UIKit



protocol URLCacheManager {
    var session: URLSession { get }
}

extension URLCacheManager {
    func setupURLCache(imageURL: String, completion: @escaping (UIImage) -> ()) {
        // 캐시 크기를 10MB로 설정
        let cacheSizeMemory = 10 * 1024 * 1024
        let cacheSizeDisk = 10 * 1024 * 1024
        let cache = URLCache(
            memoryCapacity: cacheSizeMemory,
            diskCapacity: cacheSizeDisk,
            diskPath: "/Users/mskang/Desktop/yagom-career-starter/230805/230805/NewImage"
        )
        
        // 기본 URL 세션 구성 생성
        let sessionConfig = URLSessionConfiguration.default
        sessionConfig.urlCache = cache
        
        // URL 요청 생성
        guard let url = URL(string: imageURL) else {
            return
        }
        
        let request = URLRequest(url: url)
        
        // URLSession을 사용하여 데이터 요청
        session.dataTask(with: request) { (data, response, error) in
            guard error == nil else {
                print(error?.localizedDescription ?? "오류 발생!!")
                return
            }
            
            guard let httpResponse = response as? HTTPURLResponse,
                  (200...299).contains(httpResponse.statusCode) else {
                print("HTTP RESPONSE 오류!!")
                return
            }
            
            guard let data = data else {
                print("데이터 오류 발생!!")
                return
            }
            
            guard let image = UIImage(data: data) else {
                print("이미지 변환 오류 발생!!")
                return
            }
            completion(image)
            print("디스크에서 이미지를 가져옵니다")
        }.resume()
    }

    func fetchDataFromURL(url: URL, completion: @escaping (Data?) -> Void) {
        // 캐시된 응답을 확인하고, 캐시가 있으면 바로 반환
        if let cachedResponse = URLCache.shared.cachedResponse(for: URLRequest(url: url)) {
            completion(cachedResponse.data)
            return
        }
        
        // 캐시가 없는 경우, URL 요청을 만들고 데이터를 다운로드
        let task = URLSession.shared.dataTask(with: url) { (data, response, error) in
            guard error == nil, let data = data, let response = response else {
                completion(nil)
                return
            }
            
            // URL 요청의 응답을 캐시에 저장
            let cachedData = CachedURLResponse(response: response, data: data)
            URLCache.shared.storeCachedResponse(cachedData, for: URLRequest(url: url))
            
            completion(data)
        }
        task.resume()
    }

    

}
