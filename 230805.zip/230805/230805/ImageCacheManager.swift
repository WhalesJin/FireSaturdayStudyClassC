//
//  ImageCacheManager.swift
//  230805
//
//  Created by Minseong Kang on 2023/08/05.
//

import UIKit
// 싱글톤을 생성하면 왜 race condition에 대한 고민이 생길까??
class ImageCacheManager {
    static let shared = NSCache<NSString, UIImage>()
    private init() {}
}
